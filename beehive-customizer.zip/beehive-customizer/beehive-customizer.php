<?php
/**
 * Main plugin header.
 *
 * @package Beehive
 *
 * Plugin Name: Beehive Customizer
 * Plugin URI:  http://premium.wpmudev.org/project/google-analytics-for-wordpress-mu-sitewide-and-single-blog-solution/
 * Description: Boilerplate plugin on setting some custom values for Beehive
 * Author:      Panos Lyrakis @ WPMU DEV
 * Author URI:  http://premium.wpmudev.org
 * Version:     1.0.0
 * License:     GNU General Public License (Version 2 - GPLv2)
 * Text Domain: ga_trans
 * Domain Path: /languages
 */

defined( 'WPINC' ) || die;

if ( ( defined( 'WP_CLI' ) && WP_CLI ) ) {
	return;
}

add_action( 
	'plugins_loaded',
	function(){

		if ( ! class_exists( 'WPMUDEV_Beehive_Customizer' ) ) {
    
			class WPMUDEV_Beehive_Customizer {

				private static $_instance = null;
				private $option_name = 'WPMUDEV_Beehive_Customizer_Settings';
				private $options = null;
		
				public static function instance() {

					if( is_null( self::$_instance ) ){
						self::$_instance = new WPMUDEV_Beehive_Customizer();
					}
					return self::$_instance;
					
				}

				private function __construct() {

					if( ! defined( 'BEEHIVE_VERSION' ) ){
						return;
					}

					add_action( 'beehive_admin_menu', array( $this, 'add_menu' ) );
					add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue' ) );
					add_action( 'wp_ajax_wpmudev_beehive_customizer_save', array ( $this, 'save_options_ajax' ) );

					add_filter( 'beehive_assets_get_scripts', array( $this, 'remove_orig_scripts' ), 20, 2 );

					add_filter(  'beehive_assets_scripts_common_localize_vars', array( $this, 'localize_vars' ), 20, 2 );

		
				}


				public function save_options_ajax() {

					$_post_data 		= @file_get_contents( 'php://input' );
					$post_data 			= json_decode( $_post_data );
					parse_str( $post_data->options, $options );

					if ( ! isset( $post_data->nonce ) || ! wp_verify_nonce( $post_data->nonce , 'wpmudev_beehive_customizer_nonce' ) ) {

						$return = array(
							'success'       	=>  false,
							'message' 			=> 'AJAX nonce is wrong'
						);

						wp_send_json( $return );        		

					}

					if ( update_option( $this->option_name, $options ) ) {

						$return = array(
							'success'       	=>  true,
							'message' 			=> 'Options saved'
						);

						wp_send_json( $return );   

					}

					$return = array(
						'success'       	=>  true,
						'message' 			=> 'Options were not saved'
					);

					wp_send_json( $return );   

				}


				public function remove_orig_scripts( $scripts, $admin ) {

					if ( ! $admin ) {
						return $scripts;
					}
					
					unset( $scripts[ 'beehive-statistics-page' ] );
					return $scripts;
				}


				public function localize_vars( $vars, $script ) {

					$vars[ 'customizer' ] = get_option( $this->option_name );
					/*
					$vars[ 'customizer' ] = array(
						'colors' => array(
							'stats_mediums' => 'green'
						),
					);
					*/

					return $vars;
				}

					
				public function add_menu( $settings_hook ) {

					add_submenu_page(
						'beehive',
						__( 'Beehive Customizer', 'ga_trans' ),
						__( 'Customizer', 'ga_trans' ),
						Beehive\Core\Controllers\Capability::SETTINGS_CAP,
						'beehive-customizer',
						array( $this, 'settings_page' ),
						999 // Settings should be the last one.
					);

				}

				protected function get_option( $option_group, $option, $default ){

					if ( is_null( $this->options ) ) {
						$this->options = get_option( $this->option_name );
					}

					$value = isset( $this->options[ $option_group ][ $option ] ) ? $this->options[ $option_group ][ $option ] : $default;
					return $value;

				}

				public function settings_page() {

					$visitors_back = $this->get_option( 'colors', 'stats_visitors_back', '#17A8E3' );
					$visitors_border = $this->get_option( 'colors', 'stats_visitors_border', '#FFFFFF' );
					$mediums_back = $this->get_option( 'colors', 'stats_mediums_back', '#17A8E3' );
					$mediums_border = $this->get_option( 'colors', 'stats_mediums_border', '#FFFFFF' );
					$social_back = $this->get_option( 'colors', 'stats_social_back', '#17A8E3' );
					$social_border = $this->get_option( 'colors', 'stats_social_border', '#FFFFFF' );
					$search_back = $this->get_option( 'colors', 'stats_search_back', '#17A8E3' );
					$search_border = $this->get_option( 'colors', 'stats_search_border', '#FFFFFF' );

					$map_back = $this->get_option( 'colors', 'stats_map_back', '#FFFFFF' );
					$map_dataless = $this->get_option( 'colors', 'stats_map_dataless', '#DDDDDD' );
					$map_coloraxis1 = $this->get_option( 'colors', 'stats_map_coloraxis1', '#6DD5FF' );
					$map_coloraxis2 = $this->get_option( 'colors', 'stats_map_coloraxis2', '#49BFEF' );
					$map_coloraxis3 = $this->get_option( 'colors', 'stats_map_coloraxis3', '#17A8E3' );
					$map_coloraxis4 = $this->get_option( 'colors', 'stats_map_coloraxis4', '#0582B5' );
					$map_tooltip = $this->get_option( 'colors', 'stats_map_tooltip', '#FFFFFF' );

					$linesessions_1 = $this->get_option( 'colors', 'stats_linesessions_1', '#17A8E3' );
					$linesessions_2 = $this->get_option( 'colors', 'stats_linesessions_2', '#ADDCF2' );

					$lineusers_1 = $this->get_option( 'colors', 'stats_lineusers_1', '#2D8CE2' );
					$lineusers_2 = $this->get_option( 'colors', 'stats_lineusers_2', '#9DD0FF' );

					$linepageviews_1 = $this->get_option( 'colors', 'stats_linepageviews_1', '#8D00B1' );
					$linepageviews_2 = $this->get_option( 'colors', 'stats_linepageviews_2', '#E9CCF0' );

					$linepagesess_1 = $this->get_option( 'colors', 'stats_linepagesess_1', '#3DB8C2' );
					$linepagesess_2 = $this->get_option( 'colors', 'stats_linepagesess_2', '#C0EBEF' );

					$lineavgsess_1 = $this->get_option( 'colors', 'stats_lineavgsess_1', '#2B7BA1' );
					$linelineavgsess_2 = $this->get_option( 'colors', 'stats_lineavgsess_2', '#C0EBEF' );

					$linebouncerate_1 = $this->get_option( 'colors', 'stats_linebouncerate_1', '#FFB17C' );
					$linebouncerate_2 = $this->get_option( 'colors', 'stats_linebouncerate_2', '#FFE3CF' );
					

					?>
					<div id="wpmudev-beehive-customizer">
						<h1><?php _e( 'Customize Beehive', 'ga_trans' ); ?></h1>

						<form>
							<h3><?php _e( 'Colors', 'ga_trans' ); ?></h3>

							<hr />

							<div>
								<label><?php _e( 'Line Chart - Sessions', 'ga_trans' ); ?></label>
								<div>
									<input type="color" name="colors[stats_linesessions_1]" value="<?php echo $linesessions_1; ?>" />
									<input type="color" name="colors[stats_linesessions_2]" value="<?php echo $linesessions_2; ?>" />
								</div>
							</div>

							<div>
								<label><?php _e( 'Line Chart - Users', 'ga_trans' ); ?></label>
								<div>
									<input type="color" name="colors[stats_lineusers_1]" value="<?php echo $lineusers_1; ?>" />
									<input type="color" name="colors[stats_lineusers_2]" value="<?php echo $lineusers_2; ?>" />
								</div>
							</div>

							<div>
								<label><?php _e( 'Line Chart - Pageviews', 'ga_trans' ); ?></label>
								<div>
									<input type="color" name="colors[stats_linepageviews_1]" value="<?php echo $linepageviews_1; ?>" />
									<input type="color" name="colors[stats_linepageviews_2]" value="<?php echo $linepageviews_2; ?>" />
								</div>
							</div>

							<div>
								<label><?php _e( 'Line Chart - Page/Sessions', 'ga_trans' ); ?></label>
								<div>
									<input type="color" name="colors[stats_linepagesess_1]" value="<?php echo $linepagesess_1; ?>" />
									<input type="color" name="colors[stats_linepagesess_2]" value="<?php echo $linepagesess_2; ?>" />
								</div>
							</div>

							<div>
								<label><?php _e( 'Line Chart - Avg. Sessions', 'ga_trans' ); ?></label>
								<div>
									<input type="color" name="colors[stats_linebouncerate_1]" value="<?php echo $lineavgsess_1; ?>" />
									<input type="color" name="colors[stats_linebouncerate_2]" value="<?php echo $lineavgsess_2; ?>" />
								</div>
							</div>

							<div>
								<label><?php _e( 'Line Chart - Bounce Rates', 'ga_trans' ); ?></label>
								<div>
									<input type="color" name="colors[stats_lineavgsess_1]" value="<?php echo $linebouncerate_1; ?>" />
									<input type="color" name="colors[stats_lineavgsess_2]" value="<?php echo $linebouncerate_2; ?>" />
								</div>
							</div>

							<hr />
							
							<div>
								<label><?php _e( 'Stats Visitors Background', 'ga_trans' ); ?></label>
								<div>
									<input type="color" name="colors[stats_visitors_back]" value="<?php echo $visitors_back; ?>" />
								</div>
							</div>

							<div>
								<label><?php _e( 'Stats Visitors Border', 'ga_trans' ); ?></label>
								<div>
									<input type="color" name="colors[stats_visitors_border]" value="<?php echo $visitors_border; ?>" />
								</div>
							</div>

							<hr />

							<div>
								<label><?php _e( 'Stats Mediums Background', 'ga_trans' ); ?></label>
								<div>
									<input type="color" name="colors[stats_mediums_back]" value="<?php echo $mediums_back; ?>" />
								</div>
							</div>

							<div>
								<label><?php _e( 'Stats Mediums Border', 'ga_trans' ); ?></label>
								<div>
									<input type="color" name="colors[stats_mediums_border]" value="<?php echo $mediums_border; ?>" />
								</div>
							</div>

							<hr />

							<div>
								<label><?php _e( 'Stats Social Networks Background', 'ga_trans' ); ?></label>
								<div>
									<input type="color" name="colors[stats_social_back]" value="<?php echo $social_back; ?>" />
								</div>
							</div>

							<div>
								<label><?php _e( 'Stats Social Networks Border', 'ga_trans' ); ?></label>
								<div>
									<input type="color" name="colors[stats_social_border]" value="<?php echo $social_border; ?>" />
								</div>
							</div>

							<hr />

							<div>
								<label><?php _e( 'Stats Search Engines Background', 'ga_trans' ); ?></label>
								<div>
									<input type="color" name="colors[stats_search_back]" value="<?php echo $search_back; ?>" />
								</div>
							</div>

							<div>
								<label><?php _e( 'Stats Search Engines Border', 'ga_trans' ); ?></label>
								<div>
									<input type="color" name="colors[stats_search_border]" value="<?php echo $search_border; ?>" />
								</div>
							</div>

							<hr />

							<div>
								<label><?php _e( 'Map - Background', 'ga_trans' ); ?></label>
								<div>
									<input type="color" name="colors[stats_map_back]" value="<?php echo $map_back; ?>" />
								</div>
							</div>

							<div>
								<label><?php _e( 'Map - Dataless', 'ga_trans' ); ?></label>
								<div>
									<input type="color" name="colors[stats_map_dataless]" value="<?php echo $map_dataless; ?>" />
								</div>
							</div>

							<div>
								<label><?php _e( 'Map - Coloraxis 1', 'ga_trans' ); ?></label>
								<div>
									<input type="color" name="colors[stats_map_coloraxis1]" value="<?php echo $map_coloraxis1; ?>" />
								</div>
							</div>

							<div>
								<label><?php _e( 'Map - Coloraxis 2', 'ga_trans' ); ?></label>
								<div>
									<input type="color" name="colors[stats_map_coloraxis2]" value="<?php echo $map_coloraxis2; ?>" />
								</div>
							</div>

							<div>
								<label><?php _e( 'Map - Coloraxis 3', 'ga_trans' ); ?></label>
								<div>
									<input type="color" name="colors[stats_map_coloraxis3]" value="<?php echo $map_coloraxis3; ?>" />
								</div>
							</div>

							<div>
								<label><?php _e( 'Map - Coloraxis 4', 'ga_trans' ); ?></label>
								<div>
									<input type="color" name="colors[stats_map_coloraxis4]" value="<?php echo $map_coloraxis4; ?>" />
								</div>
							</div>

							<hr />

							<p>	
								<div id="wpmudev-beehive-customizer-placeholer"></div>
								<a class="button button-primary submit">Save</a>
							</p>

							<?php wp_nonce_field( 'wpmudev_beehive_customizer_nonce', 'wpmudev_beehive_customizer_nonce' ); ?>

						</form>

					</div>


					<script type="text/javascript">
            	($=>{

            		WPMUDEV_Beehive_Customizer = {

						form : $( '#wpmudev-beehive-customizer form' ),
            			button : '',
            			placeholder : $( '#wpmudev-beehive-customizer-placeholer' ),

            			init : function(){
							this.button = this.form.find( 'a.submit' );
            				this.button.on( 'click', this.run );
            			},
            			run : async function(){

            				let body = {
								nonce 				: $( '#wpmudev_beehive_customizer_nonce' ).val(),
								options 			: WPMUDEV_Beehive_Customizer.form.serialize()
							};

            				const response = await fetch( `${window.ajaxurl}?action=wpmudev_beehive_customizer_save`, {
								method: 'POST', // or 'PUT'
								body: JSON.stringify( body )
							});
							json = await response.json();
							WPMUDEV_Beehive_Customizer.placeholder.html( '<h3>Saving</h3>' );

							if ( json.success ) {

								if ( '' !== json.message || null !== json.message ) {
									WPMUDEV_Beehive_Customizer.placeholder.html( `<h3>${json.message}</h3>` );
									return;
								}
							}
            			}
            		};

            		$(document).ready( WPMUDEV_Beehive_Customizer.init() );
            	})(jQuery);
            </script>
					<?php

				}


				public function admin_enqueue() {

					if ( ! function_exists( 'get_current_screen' ) || 'statistics_page_beehive-google-analytics' !== get_current_screen()->id ) {
						return;
					}

					wp_register_script(
						'beehive-statistics-page',
						WP_CONTENT_URL . "/plugins/beehive-customizer/assets/js/statistics-page.min.js",
						array( 'jquery', 'beehive-sui-common', 'beehive-vendors' ),
						time(),
						true
					);
				
					$bee_assets = Beehive\Core\Controllers\Assets::instance();
				
					$bee_assets->enqueue_script( 'beehive-statistics-page' );
					
					/*wp_register_script( 
						'beehive-sui-common', 
						BEEHIVE_URL . 'app/assets/js/sui-common.min.js', 
						array( 'jquery' ), 
						BEEHIVE_VERSION, 
						true
					);

					wp_enqueue_script( 'beehive-sui-common' );
					*/

				}
				
			}
		
		}

		$wpmudev_beehive_customizer = WPMUDEV_Beehive_Customizer::instance();

	}, 20
 );

